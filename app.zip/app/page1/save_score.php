<?php
session_start();

if (isset($_SESSION['user_id']) && isset($_POST['nameQ']) && isset($_POST['score'])) {
    $idEtud = $_SESSION['user_id'];
    $nameQ = $_POST['nameQ'];
    $score = $_POST['score'];

    $host = "localhost"; 
    $username = "root";  
    $password = "";    
    $dbname = "revise_toi"; 

    try {
        // Connect to the database
        $pdo = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8", $username, $password);
        $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

        // Insert the score into the database
        $query = "INSERT INTO score (idEtud, nameQ, score) VALUES (:idEtud, :nameQ, :score)";
        $stmt = $pdo->prepare($query);

        // Bind the parameters
        $stmt->bindParam(':idEtud', $idEtud, PDO::PARAM_INT);
        $stmt->bindParam(':nameQ', $nameQ, PDO::PARAM_STR);
        $stmt->bindParam(':score', $score, PDO::PARAM_INT);

        // Execute the query
        if ($stmt->execute()) {
            echo "<p style='color: green;'>Score saved successfully!</p>";
        } else {
            echo "<p style='color: red;'>Failed to save score.</p>";
        }
    } catch (PDOException $e) {
        echo "<p style='color: red;'>Database error: " . $e->getMessage() . "</p>";
    }
} else {
    echo "<p style='color: red;'>Invalid request. Please make sure you're logged in and all data is provided.</p>";
}
?>
