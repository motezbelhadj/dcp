<?php
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Retrieve user input
    $email = trim($_POST['email']);
    $password = trim($_POST['password']);

    // Validate input
    if (empty($email) || empty($password)) {
        die("All fields are required.");
    }

    // Database connection
    $servername = "localhost";
    $username = "root"; // Replace with your MySQL username
    $dbpassword = ""; // Replace with your MySQL password
    $dbname = "revise_toi";

    $conn = new mysqli($servername, $username, $dbpassword, $dbname);

    // Check connection
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    // Fetch the user from the database
    $stmt = $conn->prepare("SELECT idEtud, password FROM etudiant WHERE email = ?");
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $stmt->store_result();

    if ($stmt->num_rows > 0) {
        $stmt->bind_result($idEtud, $hashedPassword);
        $stmt->fetch();

        // Verify the password
        if (password_verify($password, $hashedPassword)) {
            // Redirect to the quiz page upon successful login
            session_start();
            $_SESSION['user_id'] = $idEtud; 
            header("Location: page1/index.html");
            exit(); // Ensure the script stops executing after the redirect
        } else {
            // Display an error message for incorrect password
            echo "<p style='color: red;'>Incorrect password.</p>";
        }
        } else {
            // Display an error message if no account is found with the email
            echo "<p style='color: red;'>No account found with that email.</p>";
        }
        

    $stmt->close();
    $conn->close();
}
?>
